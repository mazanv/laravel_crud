<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use App\Models\Wisata;
use Illuminate\Http\Request;

class WisataController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $wisatas = Wisata::paginate(2);
        return view('wisatas.index', compact('wisatas'), ['title' => 'Wisataku']);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('wisatas.create', ['title' => 'Wisataku']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate
        $request->validate([
            'nama' => 'required' ,
            'kota' => 'required',
            'harga_tiket' => 'required',
            'image' => 'required|image|mimes:jpg,jpeg,png,svg,gif|max:2048'

        ]);
     
    $image = $request->file('image');
    $image->storeAs('public/images/', $image->hashName());

        // simpan 
        Wisata::create([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            'image' => $image->hashName(),
        ]); 

        // redirect

        return redirect()->route('wisatas.index')->with('success', 'Data berhasil di tambah!');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Wisata  $wisata
     * @return \Illuminate\Http\Response
     */
    public function show(Wisata $wisata)
    {
        return view('wisatas.show', compact('wisata'), ['title' => 'Wisataku' ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Wisata  $wisata
     * @return \Illuminate\Http\Response
     */
    public function edit(Wisata $wisata)
    {
        return view('wisatas.edit', compact('wisata'), ['title' => 'Wisataku']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Wisata  $wisata
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Wisata $wisata)
    {
      //validate
      $request->validate([
        'nama' => 'required' ,
        'kota' => 'required',
        'harga_tiket' => 'required',

    ]);

    if($request->has('image')){
        $image = $request->file('image');
        $image->storeAs('public/images/', $image->hashName());
        Storage::delete('public/images/' . $wisata->image);

        $wisata->update([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            'image' => $image->hashName(),
        ]); 

    }else{
            // simpan 
    // $wisata->update($request->all()); 
        $wisata->update([
        'nama' => $request->nama,
        'kota' => $request->kota,
        'harga_tiket' => $request->harga_tiket
        ]);
        // 'image' => $image->hashName(),
    }


    // redirect

    return redirect()->route('wisatas.index')->with('success', 'Data berhasil di ubah!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Wisata  $wisata
     * @return \Illuminate\Http\Response
     */
    public function destroy(Wisata $wisata)
    {

        Storage::delete('public/images/' . $wisata->image);
        $wisata->delete();

        return redirect()->route('wisatas.index')->with('danger', 'Data berhasil di hapus!');
    }
}
