@extends('wisatas.layout')
@section('content')
<a href="{{  route('wisatas.create') }}" class="btn btn-success">Add New Destination</a><br><br>
<table class="table table-striped">
    <tr class="text-center table table-dark">
        <th>ID</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Gambar</th>
        <th>Aksi</th>
    </tr>
    @foreach ($wisatas as $wisata)
        <tr class="text-center">
            <td>{{ $wisata-> id }}</td>
            <td>{{ $wisata->nama }}</td>
            <td>{{ $wisata->kota}}</td>
            <td>{{ $wisata->harga_tiket}}</td>
            <td><img src="{{ Storage::url('public/images/' . $wisata->image) }}"  style = "width:150px;" alt=""></td>
            <td>


                <a  class="btn btn-secondary" href="{{  route('wisatas.show',  $wisata->id)}}">Show</a>
                <a class="btn btn-warning" href="{{ route('wisatas.edit',  $wisata->id)}}">Edit</a>

                <form onclick = "return confirm('Are You Sure?')" style = "display:inline;" action="{{  route('wisatas.destroy',  $wisata->id) }}" method="post">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
    @endforeach
</table>

{{ $wisatas->links() }}
@endsection