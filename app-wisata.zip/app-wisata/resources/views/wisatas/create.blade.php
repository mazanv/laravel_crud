@extends('wisatas.layout')
@section('content')
<div class="row g-3">
    <form class = "w-80" action="{{ route('wisatas.store') }}" method="post" enctype="multipart/form-data">
        @csrf
        
        <div class="mx-auto col-md-6">
            <label for="" class="label-control">Nama</label>
            <input type="text" name="nama" id="" class="form-control">
        </div>
        <div class="mx-auto col-md-6">
            <label for="" class="label-control">Kota</label>
            <input type="text" name="kota" id="" class="form-control">
        </div>
        <div class="mx-auto col-md-6">
            <label for="" class="label-control">Harga Tiket</label>
            <input type="number" name="harga_tiket" id="" class="form-control">
        </div>
        <div class="mx-auto col-md-6">
            <label for="" class="label-control">Image</label>
            <input type="file" name="image" id="" class="form-control">
        </div><br>
        <div class="mx-auto col-md-6">
            <input type="submit" value="Save" class="btn btn-outline-primary">
        </div>
</div>

    </form>

@endsection