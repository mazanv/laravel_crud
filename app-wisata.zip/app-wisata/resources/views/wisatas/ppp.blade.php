@extends('movies.layout')
@section('content')
<form action="{{ route('movies.store') }}" method="post"
enctype="multipart/form-data" class="form">
@csrf
<label for="">Title</label><br>
<input type="text" name="title" id=""><br>
<label for="">Actor</label><br>
<input type="text" name="actor" id=""><br>
<label for="">Year</label><br>
<input type="number" name="year" id=""><br>
<label for="">Rating</label><br>
<input type="text" name="rating" id=""><br>
<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>
<input type="submit" value="Save"