@extends('wisatas.layout')
@section('content')
<div class="card">
    <div class="card-header">
        <h1>{{ $wisata->nama }}</h1>
    </div>
    <div class="card-body">
        Kota : <br>{{ $wisata->kota}}
        Harga Tiket : <br>{{ $wisata->harga_tiket}}
        Gambar   : <br><img src="{{ Storage::url('public/images/' . $wisata->image) }}"  style = "width:150px;" alt="">
      
        <br><br> <a class="btn btn-outline-secondary" href="{{ route('wisatas.index',)}}">Back</a></div>
</div>
    
        
        
@endsection