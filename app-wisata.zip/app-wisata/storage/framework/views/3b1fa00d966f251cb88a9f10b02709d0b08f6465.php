<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1><?php echo e($wisata->nama); ?></h1>
    </div>
    <div class="card-body">
        Kota : <br><?php echo e($wisata->kota); ?>

        Harga Tiket : <br><?php echo e($wisata->harga_tiket); ?>

        Gambar   : <br><img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>"  style = "width:150px;" alt="">
      
        <br><br> <a class="btn btn-outline-secondary" href="<?php echo e(route('wisatas.index',)); ?>">Back</a></div>
</div>
    
        
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>